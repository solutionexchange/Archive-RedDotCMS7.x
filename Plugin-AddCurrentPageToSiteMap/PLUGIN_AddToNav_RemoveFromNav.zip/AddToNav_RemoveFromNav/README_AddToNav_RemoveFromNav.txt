-----------------------------DISCLAIMER-----------------------------
This script is not an official component of the RedDot Content 
Management Server, and is not supported or guaranteed by RedDot 
Solutions Corporation.  All claims of functionality are made by the 
script's author, and are not guaranteed by RedDot (regardless of any 
affiliation the author might have with RedDot Solutions). 

               **TEST FULLY AND USE AT YOR OWN RISK**
** THIS SCRIPT IS PROVIDED FREE OF CHARGE, AND MAY NOT BE RESOLD **

--------------------------------------------------------------------

Plugin:  Add to Navigation / Remove From Navigation

Version: 6.0

Date: May 5, 2006

Compatibility:  CMS 6.x +

Author: Michael Madden (Michael.madden@reddot.com)

Description:

This is a set of two plugins that allow for the addition and removal of a page to the site map from within Smart Edit mode.  Each of the plugins must be installed seperately by using the included XML files.

Installation:

Copy the attached XML files and ASP files directly to the CMS "PlugIns" 
directory.  Import the plugins via the Server Manager using the provided 
XML file, then activate and assign them to your project(s) using the normal 
plugin installation procedure (see Server Manger documentation for 
details).

Usage:  

When in Smart Edit mode, open a page using the Open Page reddot.  From the Action Menu at the top of the page click on the "Actions" option.  Under the "Plugins" section of the list of actions that appears, choose either "Add to navigation" or "Remove from navigation".


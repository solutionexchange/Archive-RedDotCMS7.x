﻿Place the SessionRedirect.asp into the RedDot\CMS\ASP folder.

The plugin is available by default from Administer Project Structure > Project and is 
accessed in the Action Menu as Release All Pages Completely.

The CMS web application must be running the .Net 2.0 framework 

The Release_All_Pages folder must be placed inside the ASP\Plugins folder and made a 2.0 web application
in IIS.
From IIS Manager, expand Default Web Site > CMS > Plugins > and then right click Release_All_Pages
Choose Properties, and then while under the General Tab, click Create to the right textbox which is 
to the right of Application name on the bottom half of the page.

-----------------------------DISCLAIMER-----------------------------
This script is not an official component of the RedDot Content 
Management Server, and is not supported or guaranteed by RedDot 
Solutions Corporation.  All claims of functionality are made by the 
script's author, and are not guaranteed by RedDot (regardless of any 
affiliation the author might have with RedDot Solutions). 

               **TEST FULLY AND USE AT YOR OWN RISK**
** THIS SCRIPT IS PROVIDED FREE OF CHARGE, AND MAY NOT BE RESOLD **

--------------------------------------------------------------------

Plugin: Assign Keyword to All Pages of Template

Version: 1.6

Date: May 15, 2006

Compatibility:  CMS 6.x +

Author: Michael Madden (Michael.madden@reddot.com), Hilmar Bunjes

Description:

This plugin allows you to assign a keyword to every page of a specific content class.

Installation:

Copy the attached XML file and ASP files directly to the CMS "PlugIns" 
directory.  Import the plugin via the Server Manager using the provided 
XML file, then activate and assign it to your project(s) using the normal 
plugin installation procedure (see Server Manger documentation for 
details).

Usage:  

Select a page in SmartTree and click in the Action Menu on the option
"Assign Keyword to All Pages of Template". In the pop-up windows you can
choose the category of the Keyword and the Keyword itself. 

You will be asked if you also want to assign the keyword to the content
class to have an assignment for all future pages as well. The next window
will tell you the progress of the assignment and afterwards which pages have 
been changed.

Notes:

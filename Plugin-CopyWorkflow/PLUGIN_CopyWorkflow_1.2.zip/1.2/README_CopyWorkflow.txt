-----------------------------DISCLAIMER-----------------------------
This script is not an official component of the RedDot Content 
Management Server, and is not supported or guaranteed by RedDot 
Solutions Corporation.  All claims of functionality are made by the 
script's author, and are not guaranteed by RedDot (regardless of any 
affiliation the author might have with RedDot Solutions). 

               **TEST FULLY AND USE AT YOR OWN RISK**
** THIS SCRIPT IS PROVIDED FREE OF CHARGE, AND MAY NOT BE RESOLD **

--------------------------------------------------------------------

Plugin:  Copy Workflow

Version: 1.2

Date: January 30, 2008

Compatibility:  CMS 6.x +

Author: Alexander Seifert (alexander.seifert@reddot.com).
Modifed by Gavin Cope (gavin.cope@alphawest.com.au)

Description:

This plugin copies a workflow from one project to another.

Installation:

Copy the attached XML file and ASP file{s} directly to the CMS "PlugIns" 
directory.  Import the plugin via the Server Manager using the provided 
XML file, then activate and assign it to your project(s) using the normal 
plugin installation procedure (see Server Manger documentation for 
details).

Usage:  

Click on any workflow in the project you want to copy the workflow from
and click "copy workflow" in the Action Menu. You can choose in the pop-up
windows which workflow you want to copy (all workflows of the current project 
are shown in the drop-down menu), to which project you want to copy the 
workflow and the name of the workflow in the new project.

Notes:
version 1.1: Modifed the plugin to handled blank or invalid email addresses 
on email notifications. Errors are reported and the status of the copy displayed
accordingly at the completetion of the copy workflow execution.

Version 1.2: Modified the plugin to handle RQL placeholders in the subject of
email notificaitons.